import React from 'react';
import { useNavigate } from 'react-router-dom';
import { problemsData } from '../../data/problemsData';
import './ProblemsTopics.css';

// Import icons (using react-icons for better quality match to screenshot)
import { FaPython, FaDatabase, FaJs, FaCss3Alt, FaReact, FaHtml5, FaJava, FaAngular } from 'react-icons/fa';
import { SiCplusplus } from 'react-icons/si';

const ProblemsTopics = () => {
    const navigate = useNavigate();

    const handleTopicClick = (topicKey, isQuiz) => {
        if (isQuiz) {
            navigate('/quiz');
        } else {
            navigate(`/problems/${topicKey}`);
        }
    };

    // Manual mapping to ensure EXACT order and icons as per screenshot
    // Row 1: Python, Sql, Javascript
    // Row 2: CSS, React, Html
    // Row 3: Java, C++, Angular
    const topicsMap = [
        { key: 'python', title: 'Python Problems', icon: <FaPython />, count: 3, color: '#3776AB' },
        { key: 'sql', title: 'Sql Problems', icon: <FaDatabase />, count: 3, color: '#336791' },
        { key: 'javascript', title: 'Javascript Problems', icon: <FaJs />, count: 2, color: '#F7DF1E' },
        { key: 'css', title: 'Css Problems', icon: <FaCss3Alt />, count: 2, color: '#1572B6' },
        { key: 'react', title: 'React Problems', icon: <FaReact />, count: 2, color: '#61DAFB' },
        { key: 'html', title: 'Html Problems', icon: <FaHtml5 />, count: 2, color: '#E34F26' },
        { key: 'java', title: 'Java Problems', icon: <FaJava />, count: 2, color: '#007396' },
        { key: 'c++', title: 'C++ Problems', icon: <SiCplusplus />, count: 2, color: '#00599C' },
        { key: 'angular', title: 'Angular Problems', icon: <FaAngular />, count: 2, color: '#DD0031' },
    ];

    return (
        <div className="problems-topics-container">
            <div className="topics-grid">
                {topicsMap.map((topic) => (
                    <div
                        key={topic.key}
                        className="topic-card"
                        onClick={() => handleTopicClick(topic.key, topic.isQuiz)}
                    >
                        <div className="topic-icon" style={{ color: topic.color }}>
                            {topic.icon}
                        </div>
                        <div className="topic-content">
                            <h3>{topic.title}</h3>
                            <div className="topic-stats">
                                <span>{topic.count} {topic.isQuiz ? 'Topics' : 'Problems'}</span>
                                <span className="solve-status">{topic.isQuiz ? '' : '0 Solved'}</span>
                            </div>
                            <div className="solve-link">
                                {topic.isQuiz ? 'Start Quiz →' : 'Solve Challenge →'}
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ProblemsTopics;
