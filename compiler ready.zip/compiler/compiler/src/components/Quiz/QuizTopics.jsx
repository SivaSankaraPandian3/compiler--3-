import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { quizzesApi } from '../../services/api';
import './QuizTopics.css';

const QuizTopics = () => {
    const navigate = useNavigate();
    const [topics, setTopics] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchTopics = async () => {
            try {
                setLoading(true);
                const response = await quizzesApi.getAllTopics();
                if (response.success) {
                    setTopics(response.data);
                }
            } catch (err) {
                console.error('Error fetching quiz topics:', err);
                setError('Failed to load quizzes.');
            } finally {
                setLoading(false);
            }
        };
        fetchTopics();
    }, []);

    const handleTopicClick = (topicId) => {
        navigate(`/quiz/${topicId}/beginner`);
    };

    if (loading) return <div className="loading">Loading quizzes...</div>;
    if (error) return <div className="error">{error}</div>;

    return (
        <div className="quiz-topics-container">
            <div className="topics-header">
                <h1>Programming Quizzes</h1>
                <p>Test your knowledge with topic-based quizzes</p>
            </div>

            <div className="topics-grid">
                {topics.map((topic) => (
                    <div
                        key={topic.id}
                        className="topic-card"
                        onClick={() => handleTopicClick(topic.id)}
                    >
                        <div className={`topic-icon icon-${topic.id}`}>
                            {topic.icon}
                        </div>
                        <div className="topic-content">
                            <h3>{topic.title}</h3>
                            <p className="topic-questions">
                                {topic.questionCount} Questions
                            </p>
                            <div className="topic-footer">
                                <span className="difficulty-badge">Beginner</span>
                                <span className="start-text">
                                    Start Quiz <span className="start-arrow">→</span>
                                </span>
                                <span className="start-arrow-right">→</span>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default QuizTopics;
