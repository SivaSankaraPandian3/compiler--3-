
// Mock Database for SQL
export const sqlDatabase = {
    Customers: {
        columns: ["customer_id", "first_name", "last_name", "age", "country"],
        data: [
            { customer_id: 1, first_name: "John", last_name: "Doe", age: 31, country: "USA" },
            { customer_id: 2, first_name: "Robert", last_name: "Luna", age: 22, country: "USA" },
            { customer_id: 3, first_name: "David", last_name: "Robinson", age: 22, country: "UK" },
            { customer_id: 4, first_name: "John", last_name: "Reinhardt", age: 25, country: "UK" },
            { customer_id: 5, first_name: "Betty", last_name: "Doe", age: 28, country: "UAE" }
        ]
    },
    Orders: {
        columns: ["order_id", "item", "amount", "customer_id"],
        data: [
            { order_id: 1, item: "Keyboard", amount: 400, customer_id: 4 },
            { order_id: 2, item: "Mouse", amount: 300, customer_id: 4 },
            { order_id: 3, item: "Monitor", amount: 12000, customer_id: 3 },
            { order_id: 4, item: "Keyboard", amount: 400, customer_id: 1 },
            { order_id: 5, item: "Mousepad", amount: 250, customer_id: 2 }
        ]
    },
    Shippings: {
        columns: ["shipping_id", "status", "customer_id"],
        data: [
            { shipping_id: 1, status: "Pending", customer_id: 2 },
            { shipping_id: 2, status: "Pending", customer_id: 4 }
        ]
    },
    // Adding tables for specific problems
    pets: {
        columns: ["pet_id", "pet_name", "pet_type", "owner_name", "age"],
        data: [
            { pet_id: 1, pet_name: "Buddy", pet_type: "Dog", owner_name: "Alice", age: 4 },
            { pet_id: 2, pet_name: "Mittens", pet_type: "Cat", owner_name: "Bob", age: 2 },
            { pet_id: 3, pet_name: "Rex", pet_type: "Dog", owner_name: "Charlie", age: 2 },
            { pet_id: 4, pet_name: "Tweety", pet_type: "Bird", owner_name: "David", age: 1 }
        ]
    },
    books: {
        columns: ["book_id", "title", "author", "price", "stock_quantity"],
        data: [
            { book_id: 1, title: "The Great Gatsby", author: "F. Scott Fitzgerald", price: 10.99, stock_quantity: 10 },
            { book_id: 2, title: "1984", author: "George Orwell", price: 8.99, stock_quantity: 20 },
            { book_id: 3, title: "Python 101", author: "John Doe", price: 25.00, stock_quantity: 5 },
            { book_id: 4, title: "Cheap Reads", author: "Jane Smith", price: 5.00, stock_quantity: 50 }
        ]
    },
    employees: {
        columns: ["emp_id", "emp_name", "department", "salary", "hire_date"],
        data: [
            { emp_id: 1, emp_name: "Alice", department: "IT", salary: 70000, hire_date: "2020-01-15" },
            { emp_id: 2, emp_name: "Bob", department: "HR", salary: 50000, hire_date: "2019-05-20" },
            { emp_id: 3, emp_name: "Charlie", department: "IT", salary: 80000, hire_date: "2021-03-10" },
            { emp_id: 4, emp_name: "David", department: "Sales", salary: 60000, hire_date: "2018-11-05" }
        ]
    },
    products: {
        columns: ["product_id", "product_name", "category", "price", "brand", "warranty_years"],
        data: [
            { product_id: 1, product_name: "Laptop", category: "Electronics", price: 1000, brand: "Samsung", warranty_years: 2 },
            { product_id: 2, product_name: "Phone", category: "Electronics", price: 800, brand: "Apple", warranty_years: 1 },
            { product_id: 3, product_name: "TV", category: "Electronics", price: 1200, brand: "Samsung", warranty_years: 3 },
            { product_id: 4, product_name: "Headphones", category: "Electronics", price: 150, brand: "Sony", warranty_years: 1 }
        ]
    },
    sales: {
        columns: ["sale_id", "product_id", "quantity_sold", "sale_date"],
        data: [
            { sale_id: 1, product_id: 1, quantity_sold: 2, sale_date: "2023-01-01" },
            { sale_id: 2, product_id: 2, quantity_sold: 5, sale_date: "2023-01-02" },
            { sale_id: 3, product_id: 1, quantity_sold: 1, sale_date: "2023-01-03" }
        ]
    },
    students: {
        columns: ["student_id", "student_name", "grade_level", "gpa", "enrollment_year"],
        data: [
            { student_id: 1, student_name: "Student A", grade_level: 10, gpa: 3.8, enrollment_year: 2021 },
            { student_id: 2, student_name: "Student B", grade_level: 9, gpa: 3.2, enrollment_year: 2022 },
            { student_id: 3, student_name: "Student C", grade_level: 11, gpa: 3.9, enrollment_year: 2020 },
            { student_id: 4, student_name: "Student D", grade_level: 10, gpa: 3.4, enrollment_year: 2021 }
        ]
    }
};

export const executeSQL = (query) => {
    try {
        const normalizedQuery = query.replace(/\s+/g, ' ').trim();
        const lowerQuery = normalizedQuery.toLowerCase();

        // Basic check for operation
        if (!lowerQuery.startsWith('select')) {
            if (lowerQuery.startsWith('insert')) return { message: "WriteResult({ \"nInserted\" : 1 })" };
            if (lowerQuery.startsWith('update')) return { message: "Query OK, 1 row affected" };
            if (lowerQuery.startsWith('delete')) return { message: "Query OK, 1 row deleted" };
            return { error: "Unsupported SQL operation. Try SELECT, INSERT, UPDATE, DELETE." };
        }

        // Extract Table Name
        const fromMatch = normalizedQuery.match(/from\s+(\w+)/i);
        if (!fromMatch) return { error: "No table specified in FROM clause" };

        const tableName = fromMatch[1];
        const tableKey = Object.keys(sqlDatabase).find(k => k.toLowerCase() === tableName.toLowerCase());
        const table = sqlDatabase[tableKey];

        if (!table) return { error: `Table '${tableName}' does not exist` };

        // Extract Columns
        const selectMatch = normalizedQuery.match(/select\s+(.*?)\s+from/i);
        if (!selectMatch) return { error: "Invalid SELECT syntax" };

        const columnsStr = selectMatch[1].trim();
        let selectedColumns = [];

        // Simple Aggregate Functions
        if (columnsStr.toLowerCase().includes('count(*)')) {
            return { columns: ['count'], data: [{ count: table.data.length }] };
        }

        if (columnsStr === '*') {
            selectedColumns = table.columns;
        } else {
            selectedColumns = columnsStr.split(',').map(c => {
                const part = c.trim().split('.'); // Handle 'p.name'
                return (part.length > 1 ? part[1] : part[0]).trim();
            });
        }

        // Filtering Logic
        let filteredData = [...table.data];
        const whereMatch = normalizedQuery.match(/where\s+(.*?)(?:group\s+by|order\s+by|;|$)/i);

        if (whereMatch) {
            const whereClause = whereMatch[1].trim();
            // Split by AND (simple case)
            const conditions = whereClause.split(/\s+and\s+/i);

            conditions.forEach(condition => {
                const condMatch = condition.match(/(\w+)\s*(=|>|<|>=|<=)\s*(.*)/);
                if (condMatch) {
                    let [_, column, operator, value] = condMatch;
                    value = value.trim().replace(/['"]/g, '');

                    filteredData = filteredData.filter(row => {
                        // Find column key in row (case insensitive)
                        const rowKey = Object.keys(row).find(k => k.toLowerCase() === column.toLowerCase());
                        const rowVal = row[rowKey];
                        const compVal = isNaN(value) ? value : Number(value);

                        switch (operator) {
                            case '=': return String(rowVal).toLowerCase() == String(compVal).toLowerCase();
                            case '>': return Number(rowVal) > Number(compVal);
                            case '<': return Number(rowVal) < Number(compVal);
                            case '>=': return Number(rowVal) >= Number(compVal);
                            case '<=': return Number(rowVal) <= Number(compVal);
                            default: return true;
                        }
                    });
                }
            });
        }

        // Final Projection
        const result = filteredData.map(row => {
            const projectedRow = {};
            selectedColumns.forEach(col => {
                const rowKey = Object.keys(row).find(k => k.toLowerCase() === col.toLowerCase());
                projectedRow[col] = row[rowKey];
            });
            return projectedRow;
        });

        return { columns: selectedColumns, data: result };

    } catch (error) {
        console.error("SQL Execution Error:", error);
        return { error: "Query Syntax Error: " + error.message };
    }
};

export const executeJava = (sourceCode) => {
    let outputBuffer = "";
    const variables = {};

    // Helper to evaluate simple expressions
    const evaluateExpression = (expr) => {
        expr = expr.trim();
        // String literal
        if (expr.startsWith('"') && expr.endsWith('"')) return expr.slice(1, -1);
        // Number literal
        if (!isNaN(expr)) return Number(expr);
        // Variable
        if (variables[expr] !== undefined) return variables[expr];

        // Simple Math (binary)
        const mathMatch = expr.match(/([\w\d]+)\s*([\+\-\*\/])\s*([\w\d]+)/);
        if (mathMatch) {
            const val1 = evaluateExpression(mathMatch[1]);
            const val2 = evaluateExpression(mathMatch[3]);
            const op = mathMatch[2];
            if (typeof val1 === 'number' && typeof val2 === 'number') {
                switch (op) {
                    case '+': return val1 + val2;
                    case '-': return val1 - val2;
                    case '*': return val1 * val2;
                    case '/': return val1 / val2;
                }
            }
            // String concat
            if (op === '+') return val1 + "" + val2;
        }
        return expr;
    };

    const lines = sourceCode.split('\n');

    try {
        lines.forEach(line => {
            line = line.trim();
            if (!line) return;

            // int[] arr = {1, 2, 3};
            const arrayMatch = line.match(/int\[\]\s+(\w+)\s*=\s*\{(.*)\};/);
            if (arrayMatch) {
                const values = arrayMatch[2].split(',').map(v => evaluateExpression(v.trim()));
                variables[arrayMatch[1]] = values;
            }

            // int a = 10, b = 20;
            const multiIntMatch = line.match(/int\s+(.+);/);
            if (multiIntMatch && !line.includes('[]') && !line.includes('(')) {
                const decls = multiIntMatch[1].split(',');
                decls.forEach(decl => {
                    const parts = decl.split('=');
                    if (parts.length === 2) {
                        variables[parts[0].trim()] = evaluateExpression(parts[1].trim());
                    }
                });
            }

            // sum += num;
            const addAssignMatch = line.match(/(\w+)\s*\+=\s*(.+);/);
            if (addAssignMatch) {
                const varName = addAssignMatch[1];
                if (variables[varName] !== undefined) {
                    const addedVal = evaluateExpression(addAssignMatch[2]);
                    if (typeof addedVal === 'number') {
                        variables[varName] += addedVal;
                    }
                }
            }

            // for (int num : arr)
            const forMatch = line.match(/for\s*\(int\s+(\w+)\s*:\s*(\w+)\)/);
            if (forMatch) {
                const iterVar = forMatch[1];
                const arrayVar = forMatch[2];
                if (Array.isArray(variables[arrayVar])) {
                    // Simple simulation
                    const nextLine = lines[lines.indexOf(line) + 1] || "";
                    if (nextLine.includes('+=') && nextLine.includes(iterVar)) {
                        const targetVarMatch = nextLine.match(/(\w+)\s*\+=/);
                        if (targetVarMatch) {
                            const targetVar = targetVarMatch[1];
                            variables[arrayVar].forEach(val => {
                                variables[targetVar] += val;
                            });
                        }
                    }
                }
            }

            // String s = "Text";
            const strMatch = line.match(/String\s+(\w+)\s*=\s*"(.*)";/);
            if (strMatch) variables[strMatch[1]] = strMatch[2];

            // System.out.println(...)
            if (line.includes('System.out.println')) {
                const match = line.match(/System\.out\.println\((.*)\);/);
                if (match) {
                    let content = match[1];
                    const parts = content.split('+');
                    let lineOut = "";
                    parts.forEach(part => {
                        lineOut += evaluateExpression(part);
                    });
                    outputBuffer += lineOut + "\n";
                }
            }
        });
    } catch (e) {
        outputBuffer += `\nError parsing Java: ${e.message}`;
        return { error: outputBuffer };
    }

    if (!outputBuffer) outputBuffer = "Build Success. (No output captured)";
    return { output: outputBuffer };
};

export const executeCpp = (sourceCode) => {
    let outputBuffer = "";
    const variables = {};
    const lines = sourceCode.split('\n');
    try {
        lines.forEach(line => {
            line = line.trim();
            if (!line) return;

            // Support int a = 10, b = 20;
            const multiIntMatch = line.match(/int\s+(.+);/);
            if (multiIntMatch && !line.includes('(')) {
                const decls = multiIntMatch[1].split(',');
                decls.forEach(decl => {
                    const parts = decl.split('=');
                    if (parts.length === 2) {
                        const varName = parts[0].trim();
                        const val = parts[1].trim();
                        if (!isNaN(val)) variables[varName] = Number(val);
                        else {
                            const mathMatch = val.match(/(\w+)\s*([\+\-\*\/])\s*(\w+)/);
                            if (mathMatch) {
                                const v1 = !isNaN(mathMatch[1]) ? Number(mathMatch[1]) : variables[mathMatch[1]];
                                const v2 = !isNaN(mathMatch[3]) ? Number(mathMatch[3]) : variables[mathMatch[3]];
                                if (v1 !== undefined && v2 !== undefined) {
                                    if (mathMatch[2] === '+') variables[varName] = v1 + v2;
                                    if (mathMatch[2] === '-') variables[varName] = v1 - v2;
                                    if (mathMatch[2] === '*') variables[varName] = v1 * v2;
                                    if (mathMatch[2] === '/') variables[varName] = v1 / v2;
                                }
                            }
                        }
                    }
                });
            }

            // Naive cout parser
            if (line.includes('cout')) {
                // Remove cout << and ending semicolon/endl
                let content = line.replace(/cout\s*<</, '').replace(/<<\s*endl\s*;?/, '').replace(/;/, '').trim();

                // Try to resolve content
                if (content.startsWith('"') && content.endsWith('"')) {
                    outputBuffer += content.slice(1, -1) + "\n";
                } else if (variables[content] !== undefined) {
                    outputBuffer += variables[content] + "\n";
                } else {
                    // Try simple math in cout
                    const mathMatch = content.match(/([\w\d]+)\s*([\+\-\*\/])\s*([\w\d]+)/);
                    if (mathMatch) {
                        const v1 = !isNaN(mathMatch[1]) ? Number(mathMatch[1]) : variables[mathMatch[1]];
                        const v2 = !isNaN(mathMatch[3]) ? Number(mathMatch[3]) : variables[mathMatch[3]];
                        if (v1 !== undefined && v2 !== undefined) {
                            if (mathMatch[2] === '+') outputBuffer += (v1 + v2) + "\n";
                            if (mathMatch[2] === '-') outputBuffer += (v1 - v2) + "\n";
                            if (mathMatch[2] === '*') outputBuffer += (v1 * v2) + "\n";
                            if (mathMatch[2] === '/') outputBuffer += (v1 / v2) + "\n";
                        }
                    }
                }
            }
        });
    } catch (e) {
        outputBuffer += `\nError parsing C++: ${e.message}`;
        return { error: outputBuffer };
    }
    if (!outputBuffer) outputBuffer = "Build Success. (No output captured)";
    return { output: outputBuffer };
};

export const executeCode = async (language, code, context = {}) => {
    const lang = (language || '').toLowerCase();

    if (lang === 'sql') {
        const result = executeSQL(code);
        return result;
    }

    if (lang === 'java') {
        return executeJava(code);
    }

    if (lang === 'c++' || lang === 'cpp') {
        return executeCpp(code);
    }

    if (lang === 'python') {
        if (!context.pyodide) {
            return { error: 'Python engine not initialized.' };
        }
        try {
            let output = "";
            context.pyodide.setStdout({
                batched: (msg) => { output += msg + "\n"; }
            });
            const result = await context.pyodide.runPythonAsync(code);
            if (!output && result !== undefined) {
                output = result.toString();
            }
            return { output: output || "Executed successfully." };
        } catch (error) {
            return { error: error.message };
        }
    }

    if (lang === 'javascript' || lang === 'js') {
        try {
            let logs = [];
            const originalLog = console.log;
            console.log = (...args) => logs.push(args.join(' '));
            new Function(code)();
            console.log = originalLog;
            return { output: logs.join('\n') || "Executed successfully." };
        } catch (e) {
            return { error: e.message };
        }
    }

    if (lang === 'html' || lang === 'css') {
        const hasHtmlTags = /<[a-z][\s\S]*>/i.test(code);
        const isFullHtml = /<html[\s\S]*>/i.test(code);

        if (isFullHtml) {
            return { html: code };
        }

        const processedCode = (lang === 'css' && !hasHtmlTags)
            ? `<style>${code}</style><div class="container"><div class="box">Default Box</div></div>`
            : code;

        // Use Base64 to safely inject code and avoid any template literal escaping issues
        const base64Code = btoa(unescape(encodeURIComponent(processedCode)));

        const htmlTemplate = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 0; color: #333; margin: 0; background: #fff; display: flex; flex-direction: column; height: 100vh; }
    #output-viewport { flex: 1; padding: 20px; overflow-y: auto; box-sizing: border-box; }
    #console-logs { 
        height: 150px; 
        background: #1e1e1e; 
        color: #d4d4d4; 
        padding: 10px; 
        font-family: 'SFMono-Regular', Consolas, monospace; 
        font-size: 12px; 
        overflow-y: auto; 
        border-top: 2px solid #333;
        box-sizing: border-box;
    }
    .log-entry { margin-bottom: 4px; padding: 2px 4px; border-radius: 2px; white-space: pre-wrap; word-break: break-all; }
    .log-info { color: #9cdcfe; }
    .log-error { color: #f48771; background: rgba(244, 135, 113, 0.1); }
    .log-warn { color: #cca700; }
    
    .container { border: 2px dashed #ccc; padding: 20px; min-height: 100px; border-radius: 8px; margin-bottom: 15px; }
    .box { background: #4a5568; color: white; padding: 15px; border-radius: 4px; text-align: center; }
  </style>
  <script>
    window.onerror = function(msg, url, line, col, error) {
      const logContainer = document.getElementById('console-logs');
      if (logContainer) {
        const div = document.createElement('div');
        div.className = 'log-entry log-error';
        div.textContent = '✖ Run Error: ' + msg;
        logContainer.appendChild(div);
        logContainer.scrollTop = logContainer.scrollHeight;
      }
      return false;
    };
  </script>
</head>
<body>
  <div id="output-viewport"></div>
  <div id="console-logs"></div>
  <script>
    (function() {
      const logContainer = document.getElementById('console-logs');
      const originalLog = console.log;
      const originalError = console.error;
      const originalWarn = console.warn;
      
      const addLog = (msg, type = 'info') => {
        const div = document.createElement('div');
        div.className = 'log-entry log-' + type;
        div.textContent = (type === 'error' ? '✖ ' : type === 'warn' ? '⚠ ' : '› ') + 
                          (typeof msg === 'object' ? JSON.stringify(msg) : msg);
        logContainer.appendChild(div);
        logContainer.scrollTop = logContainer.scrollHeight;
      };

      console.log = (...args) => { addLog(args.join(' '), 'info'); originalLog.apply(console, args); };
      console.error = (...args) => { addLog(args.join(' '), 'error'); originalError.apply(console, args); };
      console.warn = (...args) => { addLog(args.join(' '), 'warn'); originalWarn.apply(console, args); };

      // Safely inject code
      try {
        const decodedCode = decodeURIComponent(escape(atob('${base64Code}')));
        document.getElementById('output-viewport').innerHTML = decodedCode;
        
        // Execute scripts in injected content
        const scripts = document.getElementById('output-viewport').querySelectorAll('script');
        scripts.forEach(oldScript => {
            const newScript = document.createElement('script');
            Array.from(oldScript.attributes).forEach(attr => newScript.setAttribute(attr.name, attr.value));
            newScript.appendChild(document.createTextNode(oldScript.innerHTML));
            oldScript.parentNode.replaceChild(newScript, oldScript);
        });
      } catch (e) {
        addLog('Injection Error: ' + e.message, 'error');
      }
    })();
  </script>
</body>
</html>
        `;
        return { html: htmlTemplate };
    }

    if (lang === 'react') {
        const base64Code = btoa(unescape(encodeURIComponent(code)));
        const reactTemplate = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <script src="https://unpkg.com/react@18/umd/react.development.js" crossorigin></script>
  <script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js" crossorigin></script>
  <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 0; color: #333; margin: 0; background: #fff; display: flex; flex-direction: column; height: 100vh; }
    #root { flex: 1; min-height: 100px; padding: 20px; box-sizing: border-box; overflow-y: auto; }
    #console-logs { 
        height: 150px; 
        background: #1e1e1e; 
        color: #d4d4d4; 
        padding: 10px; 
        font-family: 'SFMono-Regular', Consolas, monospace; 
        font-size: 12px; 
        overflow-y: auto; 
        border-top: 2px solid #333;
    }
    .log-entry { margin-bottom: 4px; padding: 2px 4px; border-radius: 2px; white-space: pre-wrap; word-break: break-all; }
    .log-info { color: #9cdcfe; }
    .log-error { color: #f48771; background: rgba(244, 135, 113, 0.1); }
    .log-warn { color: #cca700; }
  </style>
</head>
<body>
  <div id="root"></div>
  <div id="console-logs"></div>
  <script type="text/babel">
    const logContainer = document.getElementById('console-logs');
    const originalLog = console.log;
    const originalError = console.error;
    const originalWarn = console.warn;
    const addLog = (msg, type = 'info') => {
        const div = document.createElement('div');
        div.className = 'log-entry log-' + type;
        div.textContent = (type === 'error' ? '✖ ' : type === 'warn' ? '⚠ ' : '› ') + (typeof msg === 'object' ? JSON.stringify(msg) : msg);
        logContainer.appendChild(div);
        logContainer.scrollTop = logContainer.scrollHeight;
    };
    console.log = (...args) => { addLog(args.join(' '), 'info'); originalLog.apply(console, args); };
    console.error = (...args) => { addLog(args.join(' '), 'error'); originalError.apply(console, args); };
    console.warn = (...args) => { addLog(args.join(' '), 'warn'); originalWarn.apply(console, args); };
    
    const { useState, useEffect, useCallback, useMemo, useRef, useReducer, useContext } = React;
    
    try {
        const code = decodeURIComponent(escape(atob('${base64Code}')));
        const processedCode = code
            .replace(/import\\s+[\\s\\S]*?\\s+from\\s+['"].*?['"];?/g, '')
            .replace(/export default (\\w+);?/g, 'window.DefaultExport = $1;')
            .replace(/export (const|class|function)/g, '$1');

        const evalCode = Babel.transform(processedCode, { presets: ['react'] }).code;
        eval(evalCode);
        let ComponentToRender = null;
        if (window.DefaultExport) ComponentToRender = window.DefaultExport;
        else if (typeof App !== 'undefined') ComponentToRender = App;
        else if (typeof Counter !== 'undefined') ComponentToRender = Counter;
        else {
           const possibleComponents = Object.keys(window).filter(key => 
               typeof window[key] === 'function' && !['React', 'ReactDOM', 'Babel'].includes(key) &&
               (/^[A-Z]/.test(key) || key.toLowerCase() === 'counter' || key.toLowerCase() === 'app')
           );
           if (possibleComponents.length > 0) ComponentToRender = window[possibleComponents[0]];
        }
        if (ComponentToRender) {
            const root = ReactDOM.createRoot(document.getElementById('root'));
            root.render(React.createElement(ComponentToRender));
        } else {
            addLog('Could not find a React component to render. Make sure your component name is capitalized.', 'error');
        }
    } catch (e) {
        addLog('Runtime Error: ' + e.message, 'error');
    }
  </script>
</body>
</html>
        `;
        return { html: reactTemplate };
    }

    if (lang === 'angular') {
        const base64Code = btoa(unescape(encodeURIComponent(code)));
        const angularTemplate = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <script src="https://unpkg.com/reflect-metadata@0.1.13/Reflect.js"></script>
  <script src="https://unpkg.com/zone.js@0.11.4/dist/zone.min.js"></script>
  <script src="https://unpkg.com/rxjs@7.5.5/dist/bundles/rxjs.umd.min.js"></script>
  <script src="https://unpkg.com/@angular/core@14.2.0/bundles/core.umd.js"></script>
  <script src="https://unpkg.com/@angular/common@14.2.0/bundles/common.umd.js"></script>
  <script src="https://unpkg.com/@angular/compiler@14.2.0/bundles/compiler.umd.js"></script>
  <script src="https://unpkg.com/@angular/platform-browser@14.2.0/bundles/platform-browser.umd.js"></script>
  <script src="https://unpkg.com/@angular/platform-browser-dynamic@14.2.0/bundles/platform-browser-dynamic.umd.js"></script>
  <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
  <style>
    body { font-family: sans-serif; padding: 20px; margin: 0; }
    #console-logs { 
        position: fixed; bottom: 0; left: 0; right: 0;
        height: 120px; background: #1e1e1e; color: #d4d4d4; 
        padding: 10px; font-family: monospace; font-size: 12px; 
        overflow-y: auto; border-top: 2px solid #333; z-index: 1000;
    }
    .log-entry { margin-bottom: 4px; border-radius: 2px; }
    .log-error { color: #f48771; }
  </style>
</head>
<body>
  <app-root><div style="color: #666; padding: 20px;">Bootstrapping Angular...</div></app-root>
  <div id="console-logs"></div>
  <script>
    const logContainer = document.getElementById('console-logs');
    const addLog = (msg, type = 'info') => {
        const div = document.createElement('div');
        div.className = 'log-entry log-' + type;
        div.textContent = (type === 'error' ? '✖ ' : '› ') + (typeof msg === 'object' ? JSON.stringify(msg) : msg);
        logContainer.appendChild(div);
        logContainer.scrollTop = logContainer.scrollHeight;
    };
    window.onerror = (msg) => addLog(msg, 'error');
    console.log = (...args) => addLog(args.join(' '));
    console.error = (...args) => addLog(args.join(' '), 'error');

    (async function() {
      try {
        const rawCode = decodeURIComponent(escape(atob('${base64Code}')));
        const { Component, NgModule, enableProdMode } = ng.core;
        const { BrowserModule } = ng.platformBrowser;
        const { platformBrowserDynamic } = ng.platformBrowserDynamic;

        // Strip imports and exports for JIT
        const processedCode = rawCode
            .replace(/import\\s+[\\s\\S]*?\\s+from\\s+['"].*?['"];?/g, '')
            .replace(/export\\s+class/g, 'class');

        // Transpile with Babel support for decorators
        const evalCode = Babel.transform(processedCode, {
            presets: ['typescript'],
            plugins: [['proposal-decorators', { legacy: true }], 'proposal-class-properties']
        }).code;

        eval(evalCode);

        // Find the component class name from the code
        const classMatch = processedCode.match(/class\s+(\w+)/);
        const className = classMatch ? classMatch[1] : 'AppComponent';
        
        // Force exposing it to window so bootstrap can see it
        try { window.AppComponentClass = eval(className); } catch(e) {
            // Fallback: try to find any class on window that looks like a component
            window.AppComponentClass = window[className] || window.AppComponent;
        }

        if (!window.AppComponentClass) {
            throw new Error('Could not find component class: ' + className);
        }

        // Re-transpile the bootstrap module too because browsers don't support decorators
        const bootstrapCode = Babel.transform(\`
            @ng.core.NgModule({
              imports: [ng.platformBrowser.BrowserModule],
              declarations: [window.AppComponentClass],
              bootstrap: [window.AppComponentClass]
            })
            class AppModule {}
            ng.platformBrowserDynamic.platformBrowserDynamic().bootstrapModule(AppModule);
        \`, {
            presets: ['typescript'],
            plugins: [['proposal-decorators', { legacy: true }], 'proposal-class-properties']
        }).code;

        eval(bootstrapCode);
      } catch (e) {
        addLog('Angular Loader Error: ' + e.message, 'error');
        console.error(e);
      }
    })();
  </script>
</body>
</html>
        `;
        return { html: angularTemplate };
    }

    return { error: `Execution for ${language} is not supported yet.` };
};
